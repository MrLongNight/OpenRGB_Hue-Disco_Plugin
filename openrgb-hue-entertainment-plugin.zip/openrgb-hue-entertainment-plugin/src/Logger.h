#pragma once

#include <spdlog/spdlog.h>

void InitializeLogger();
