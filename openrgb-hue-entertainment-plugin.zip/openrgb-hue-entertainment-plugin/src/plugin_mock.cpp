#include "OpenRGB/Plugin.h"
#include <iostream>

void register_device(Device* device) {
    std::cout << "Mock: Registering device" << std::endl;
}
